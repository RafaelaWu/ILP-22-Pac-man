def get_pos(pos):
	if pos == "[0.16, 0.16, 0.33, 0.33]":
		return "11"
	elif pos == "[0.16, 0.5, 0.33, 0.33]":
		return "12"
	elif pos == "[0.16, 0.83, 0.33, 0.33]":
		return "13"
	elif pos == "[0.5, 0.16, 0.33, 0.33]":
		return "21"
	elif pos == "[0.5, 0.5, 0.33, 0.33]":
		return "22"
	elif pos == "[0.5, 0.83, 0.33, 0.33]":
		return "23"
	elif pos == "[0.83, 0.16, 0.33, 0.33]":
		return "31"
	elif pos == "[0.83, 0.5, 0.33, 0.33]":
		return "32"
	elif pos == "[0.83, 0.83, 0.33, 0.33]":
		return "33"
	elif pos == "[0.25, 0.25, 0.5, 0.5]" or pos == "[0.42, 0.42, 0.15, 0.15]":
		return "up-left"	
	elif pos == "[0.25, 0.75, 0.5, 0.5]" or pos == "[0.42, 0.58, 0.15, 0.15]":
		return "up-right"	
	elif pos == "[0.75, 0.25, 0.5, 0.5]" or pos == "[0.58, 0.42, 0.15, 0.15]":
		return "down-left"	
	elif pos == "[0.75, 0.75, 0.5, 0.5]" or pos == "[0.58, 0.58, 0.15, 0.15]":
		return "down-right"	
	elif pos == "[0.5, 0.5, 1, 1]":
		return "center"
	elif pos == "[0.5, 0.25, 0.5, 0.5]":
		return "left"
	elif pos == "[0.5, 0.75, 0.5, 0.5]":
		return "right"
	elif pos == "[0.25, 0.5, 0.5, 0.5]":
		return "up"
	elif pos == "[0.75, 0.5, 0.5, 0.5]":
		return "down"
	else:
		raise Exception('error in position'+ pos)

